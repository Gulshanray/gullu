export type TestimonialType = {
  profession: string
  name: string
  imgSrc: string
  starimg: string
  detail: string
}
