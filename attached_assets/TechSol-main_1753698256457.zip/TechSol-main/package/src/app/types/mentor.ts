export type MentorType = {
  name: string
  href: string
  imageSrc: string
  imageAlt: string
  color: string
}
