export type Hourtype = {
  name: string
}
