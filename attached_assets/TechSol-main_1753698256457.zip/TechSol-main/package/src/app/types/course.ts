export type CourseType = {
  name: string
}
